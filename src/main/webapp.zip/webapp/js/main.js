$(function(){


    $("#signup").on("submit",function (e) {
        const username = $("#username").val();
        const email = $("#email").val();
        const password = $("#password").val();
        const confirm_password = $("#confirm_password").val();
     e.preventDefault();
     if(username.length<4){
      alert(username.length+" username must be greater than 5")
     }
     else if(email===""){
         alert("email cannot be empty")
     }
     else if(password!==confirm_password && password!==""){
      alert("password does not match")
     }else {
      $.ajax({
       url: "http://localhost:8080/Store_war_exploded/register",
       type: "POST",
       data: new FormData(this),
       cache: false,
       contentType: false,
       processData: false,
       beforeSend: () => {alert("processing");},
       success: (data) => { alert(data) },
       error:(err)=>{
        alert(err)
       }

      })
     }

    })

});